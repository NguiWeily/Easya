from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from fpdf import FPDF
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

transactions = []

@app.route("/api/send-otp", methods=["POST"])
def send_otp():
    return jsonify({"otp": "123456", "message": "OTP sent successfully."})

@app.route("/api/transfer", methods=["POST"])
def transfer():
    data = request.json
    data["timestamp"] = datetime.utcnow().isoformat()
    transactions.append(data)
    return jsonify({"status": "success", "message": "Transaction completed", "data": data})

@app.route("/api/transactions", methods=["GET"])
def get_transactions():
    return jsonify(transactions)

@app.route("/api/receipt", methods=["POST"])
def generate_receipt():
    data = request.json
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Transaction Receipt", ln=True, align="C")
    for key, value in data.items():
        pdf.cell(200, 10, txt=f"{key.capitalize()}: {value}", ln=True, align="L")
    filepath = "receipt.pdf"
    pdf.output(filepath)
    return send_file(filepath, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)
