import React, { useState, useEffect } from "react";
import axios from "axios";

function App() {
  const [amount, setAmount] = useState("");
  const [recipient, setRecipient] = useState("");
  const [currency, setCurrency] = useState("USD");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [transactions, setTransactions] = useState([]);

  const sendOtp = async () => {
    const res = await axios.post("http://localhost:5000/api/send-otp");
    alert("OTP sent: " + res.data.otp);
    setOtpSent(true);
  };

  const submitTransfer = async () => {
    const data = { amount, recipient, currency, otp };
    const res = await axios.post("http://localhost:5000/api/transfer", data);
    alert(res.data.message);
    setOtp("");
    fetchTransactions();
  };

  const fetchTransactions = async () => {
    const res = await axios.get("http://localhost:5000/api/transactions");
    setTransactions(res.data);
  };

  const downloadReceipt = async (tx) => {
    const res = await axios.post(
      "http://localhost:5000/api/receipt",
      tx,
      { responseType: "blob" }
    );
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "receipt.pdf");
    document.body.appendChild(link);
    link.click();
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">SeamlessCross</h1>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 mb-6">
        <input className="border p-2" placeholder="Amount" value={amount} onChange={(e) => setAmount(e.target.value)} />
        <input className="border p-2" placeholder="Recipient" value={recipient} onChange={(e) => setRecipient(e.target.value)} />
        <select className="border p-2" value={currency} onChange={(e) => setCurrency(e.target.value)}>
          <option value="USD">USD</option>
          <option value="EUR">EUR</option>
          <option value="SGD">SGD</option>
        </select>
        {otpSent && <input className="border p-2" placeholder="Enter OTP" value={otp} onChange={(e) => setOtp(e.target.value)} />}
      </div>
      {!otpSent ? (
        <button onClick={sendOtp} className="bg-blue-600 text-white px-4 py-2 rounded">Request OTP</button>
      ) : (
        <button onClick={submitTransfer} className="bg-green-600 text-white px-4 py-2 rounded">Send Payment</button>
      )}
      <h2 className="text-xl font-semibold mt-8 mb-4">Transactions</h2>
      <ul className="space-y-2">
        {transactions.map((tx, idx) => (
          <li key={idx} className="border p-3 rounded shadow flex flex-col md:flex-row justify-between items-center">
            <span>{tx.amount} {tx.currency} → {tx.recipient}</span>
            <button onClick={() => downloadReceipt(tx)} className="bg-gray-800 text-white px-3 py-1 mt-2 md:mt-0 rounded">Download Receipt</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
